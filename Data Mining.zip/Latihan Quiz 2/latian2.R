orders <- read.csv('orders.csv', sep = ',', fileEncoding = 'UTF-8-BOM')
products <- read.csv('products.csv', sep = ',', fileEncoding = 'UTF-8-BOM')

#Data Visualization
#a). Boxplot
boxplot(products$product_price ~ products$department,
        main = 'Product Price for All Product Department',
        xlab = 'Department',
        ylab = 'Product Price',
        col = rainbow(length(unique(products$department))),
        las = 2
        )

#Additional Histogram
hist(products$product_price,
     main = 'Product Price for All product Department',
     xlab = 'Product Price',
     col = rainbow(length(unique(products$product_price))),
     las = 2
     )

#b). Pie Chart
department <- table(products$department)
top5department <- head(sort(department, decreasing = TRUE), 5)
others <- tail(sort(department, decreasing = TRUE), length(sort(department, decreasing = TRUE))-5)
otherss <- c(top5department, others = sum(others))
label <- paste(names(otherss), "(", round(otherss * 100 / sum(otherss), 2), "%)")

pie(otherss, labels = label, col = rainbow(length(unique(otherss))),
    main = 'Top 5 Department (Based on Product Count)'
)

#c). BarChart
frozen = subset(products, (products$department == 'frozen'))
frozen2 = table(frozen$aisle)
bot3 = head(sort(frozen2, increasing = TRUE))[1:3]

barplot(bot3,
        main = 'Lowest 3 Aisle in Frozen Department (Based on Product Count)',
        col = rainbow(length(unique(frozen2)))
)


#Number 2

merged <- merge(orders, products, by = 'product_id')
merged <- subset(merged, department == 'alcohol'& aisle != 'speciality wines champagnes')
merged <- merged[!duplicated(merged), ]

library(arules)
