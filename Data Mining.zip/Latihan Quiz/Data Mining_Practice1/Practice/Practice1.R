orders = read.csv('orders.csv', sep = ',', fileEncoding = 'UTF-8-BOM')
products = read.csv('products.csv', sep =',', fileEncoding = 'UTF-8-BOM')

boxplot(products$product_price ~ products$department,
        main = 'Product Price for All Product Department',
        xlabel = 'department',
        ylabel = 'product price',
        col = rainbow(length(unique(products$department))))

department = table(products$department)
top5 = head(sort(department, decreasing = TRUE), 5)
others = tail(sort(department, decreasing = TRUE), length(sort(department, decreasing = TRUE))-5)
otherss = c(top5, others = sum(others))
label = paste(names(otherss), "(",round(otherss*100/sum(otherss), 2),"%)")

pie(otherss, labels = label, col = rainbow(length(unique(otherss))),
    main = 'Top 5 Departments (Based on Product Count)')

frozen = subset(products, (products$department == 'frozen'))

frozen2 = table(frozen$aisle)
bot3 = head(sort(frozen2, increasing = TRUE))[1:3]

barplot(bot3, 
        main = 'Lowest 3 Aisle in Frozen Department (Based on Product Count)',
        col = rainbow(length(unique(frozen2))))

merged <- merge(orders, products, by = 'product_id')
merged <- subset(merged, department == 'alcohol' & aisle != 'specialty wines champagnes')
merged <- merged[!duplicated(merged), ]

library(arules)

transactions <- split(merged$product_name, merged$order_id)
transactions <- as(transactions, 'transactions')

freq = apriori(transactions, parameter = list(support = 0.04, target = 'frequent items'))
inspect(freq)

freq= apriori(transactions, parameter = list(support = 0.04, confidence = 0.5, target = 'rules'))
inspect(freq)

write.csv(merged, 'merged.csv')
