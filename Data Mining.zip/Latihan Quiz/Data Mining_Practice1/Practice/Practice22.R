library(arules)
library(ggplot2)
library(dplyr)

productsdf = read.csv("products.csv")
ordersdf = read.csv("orders.csv")

productsdf <- na.omit(productsdf)
ordersdf <- na.omit(ordersdf)

# 1. a. 
ggplot(productsdf, aes(x = department, y = product_price, fill = department)) +
  geom_boxplot() +
  labs(title = "Product Price for All Product Department") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1), legend.position = "none", plot.title = element_text(hjust = 0.5) )
  
# 1. b. 
departmentCount <- productsdf %>%
  group_by(department) %>%
  summarise(count = n())

top5 <- departmentCount %>%
  slice_max(count, n = 5)

others <- productsdf %>%
  mutate(others = ifelse(department %in% top5$department, department, "Other"))

finalList <- others %>%
  group_by(others) %>%
  summarise(count = n()) %>%
  mutate(percentage = round(count/sum(count) * 100, 1)) %>%
  arrange(percentage)

finalList

labels <- paste(finalList$others, "(", finalList$percentage,"%",")")

pie(finalList$count, main = "Top 5 Department (Based on Product Count)", labels = labels, col = rainbow(length(finalList$others)))

# 1. c. 
frozendf <- productsdf %>%
  filter(department == "frozen")

countAisle <- frozendf %>%
  group_by(aisle) %>%
  summarise(count = n())

least3 <- countAisle %>%
  slice_min(count, n = 3)

barplot(least3$count, names.arg = least3$aisle, col = rainbow(length(least3$aisle)), main = "Lowest 3 Aisle in frozen Department (Based on Product Count)")



# 2. a. 
alcohol <- productsdf %>%
  filter(department == "alcohol")

alcohol <- alcohol %>%
  filter(aisle != "Specialty wines champagnes")

alcohol = alcohol[!duplicated(alcohol), ]

# 2. b. 
alcohol <- merge(alcohol, ordersdf, by = "product_id")
alcohol <- split(alcohol$product_name, alcohol$order_id)
alcohol <- lapply(alcohol, unique)
t_alcohol <- as(alcohol, "transactions")

# 2. c. 
minSupport <- 0.04
minConfidence <- 0.5

rules <- apriori(t_alcohol, parameter = list(supp = minSupport, conf = minConfidence, target = "frequent itemsets"))
inspect(rules)

rules <- apriori(t_alcohol, parameter = list(supp = minSupport, conf = minConfidence, target = "rules"))
inspect(rules)

