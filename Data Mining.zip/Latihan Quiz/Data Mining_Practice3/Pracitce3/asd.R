participant = read.csv('Participant.csv', sep =',')
question = read.csv('question.csv', sep = ',')
result = read.csv('result.csv', sep = ',')

pie = table(result$Question.2)
labels = pie*100/sum(pie)
pie(pie, label = labels, col = rainbow(length(unique(pie))))
legend('topright',
       legend = c("Strongly Agree", "Agree", "Neutral", "Disagree", "Strongly Disagree"),
       fill = rainbow(length(unique(pie))))

merged1 = merge(participant, result, by = 'Participant.Number')

merged1 = subset(merged1, merged1$Gender == 'Female')

pie2 = table(merged1$Question.6)
labels = pie2*100/sum(pie2)
pie(pie2, labels = labels, col = rainbow(length(unique(pie2))))
legend('topright',
       legend = c("False", "True"),
       fill = rainbow(length(unique(pie2))))

merged2 = merge(participant, result, by = 'Participant.Number')
bar1 = subset(merged2, merged2$Gender == 'Male')
bar2 = subset(merged2, merged2$Gender == 'Female')

bars1 = table(bar1$Question.1)
bars2 = table(bar2$Question.1)

barplot(rbind(bars1,bars2),
        col = c("red", "orange"))

merged2 = merge(participant, result, by = 'Participant.Number')
boxplot(merged2$Question.1 ~ merged2$Gender, col = rainbow(length(unique(merged2$Gender))))
hist(merged2$Question.4)

ques1 = table(merged2$Question.1)
ques2 = table(merged2$Question.2)
ques3 = table(merged2$Question.3)
ques4 = table(merged2$Question.4)
ques5 = table(merged2$Question.5)

quest = rbind(ques1, ques2, ques3, ques4, ques5)

barplot(quest, beside = FALSE, 
        col = rainbow(length(unique(question$Question.Number-5))))

date <- table(result$Date)
plot(date)
