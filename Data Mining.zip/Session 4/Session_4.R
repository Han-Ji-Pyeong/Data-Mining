#Session 4
# Contribution
#1. Apriori
#     - Install arules
#     - Ubah jadi bentuk factor
#     - Ubah list jadi "transactions" / arules
#2. FP-Growth

install.packages('arules') #Buat Install
library(arules) #Buat Pakai

#Import
header <- read.csv('Header.csv', fileEncoding = "UTF-8-BOM", na.strings = c("", "N/A"))
games <- read.csv('Games.csv', fileEncoding = "UTF-8-BOM", na.strings = c("", "N/A"))
detail <- read.csv('Detail.csv', fileEncoding = "UTF-8-BOM", na.strings = c("", "N/A"))

#Merge
transactions <- merge(header, detail, by = 'TransactionId') #Merge header sama detail
transactions <- merge(transactions, games, by = 'GameId') #Merge transactions sama games

#Omit data -> Filtering data
# Data Frame                       Row                     Column
transactions <- transactions[complete.cases(transactions) , ]

#Ambil TransactionId, Quantity, Name
transactions <- transactions[ , c("TransactionId", "Quantity", "Name")]

#Ubah jadi bentuk factor -> kita mau bentuk kita semua categorical agar lebih teridentified category limit
transactions <- lapply(transactions, as.factor)

#Drop Level : Optional
class(transactions)
transactions$TransactionId <- droplevels(transactions$TransactionId)
transactions$Name <- droplevels(transactions$Name)
transactions$Quantity <- droplevels(transactions$Quantity)

#Ubah list jadi "transactions" / arules
transactionsData <- split(x = transactions$Name, f = transactions$TransactionId) 
transactionsData <- as(transactionsData , "transactions" )
class(transactionsData)

#Apply Apriori
rules <- apriori(data = transactionsData ,parameter = list(support = 0.005, target = "frequent itemsets"))

inspect(ruleInduction(x = rules , confidence = 0.15))
