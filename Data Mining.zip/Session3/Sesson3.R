#Kosong
#NA
name <- c("Eldrian", "Yoseft", NA, "Gilbert", "Eldrian")
is.na(name)

name[!is.na(name)]

#Duplicate
duplicated(name)

name <- name[!duplicated(name)]

iris <- read.csv("Iris.csv", sep = ",", fileEncoding = "UTF-8-BOM", na.strings = "")
#Cara menghilangkan data data yang NA/Kosong
iris <- na.omit(iris)

#Filter
subset(
  iris, iris$SepalLengthCm > 5, c("SepalLengthCm", "Species")
)

summary(iris)
#mean,min,max,median,sd
mean(iris$SepalLengthCm)
min(iris$SepalLengthCm)
max(iris$SepalLengthCm)
median(iris$SepalLengthCm)
sd(iris$SepalLengthCm)

#Aggregate
#Avg dari SepalLengthCm
#Untuk setiap species
aggregate(
  SepalLengthCm~Species, iris, mean
)

#Beberapa kolom diagregatin
aggregate(
  cbind(SepalLengthCm, SepalWidthCm)~Species, iris, mean
)

#Order
score <- c(1,10,4,6)
order(score)
score[order(score)]

#gsub -> replace suatu character dalam sebuah string
harga <- "150.000"
harga <- gsub(".","",harga, fixed = TRUE)
as.integer(harga)
