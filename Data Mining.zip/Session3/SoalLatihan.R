rate <- read.csv("Exchange Rate.csv", sep = ",", fileEncoding = "UTF-8-BOM", na.strings = "")

rate.btc <- rate[rate$Cryptocurrency == "BTC",]
rate.xrp <- rate[rate$Cryptocurrency == "XRP",]
rate.eth <- rate[rate$Cryptocurrency == "ETH",]

order(rate.btc$Date, rate.btc$Time)
rate <- rate.btc[order(rate.btc$Date, rate.btc$Time),]
rate <- rate.xrp[order(rate.xrp$Date, rate.xrp$Time),]
rate <- rate.eth[order(rate.eth$Date, rate.eth$Time),]

rate.eth.16aug <- rate.eth[rate.eth$Date == "16-Aug-18",]

rate.eth.16aug$Price[1]
paste("Open Price :RP,", rate.eth.16aug$Price[1])
paste("Close Price :RP,", rate.eth.16aug$Price[nrow(rate.eth.16aug)])

rate.xrp$Price <- gsub(".","",rate.xrp$Price, fixed = TRUE)
rate.xrp$Price <- as.integer(rate.xrp$Price)

#Aggregation mean()
mean.eachday <- aggregate(
  Price~Date, rate.xrp, mean
)

  
plot(
  mean.eachday$Price, type = "b"
)